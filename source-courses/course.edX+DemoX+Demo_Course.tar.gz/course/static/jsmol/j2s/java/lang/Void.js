$_L(null,"java.lang.Void",["java.lang.RuntimeException"],function(){
c$=$_T(java.lang,"Void");
$_S(c$,
"TYPE",null);
{
java.lang.Void.TYPE=java.lang.Void;
}});
