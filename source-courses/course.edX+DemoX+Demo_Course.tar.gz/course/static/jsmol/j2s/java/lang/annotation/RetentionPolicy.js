$_L(["java.lang.Enum"],"java.lang.annotation.RetentionPolicy",null,function(){
c$=$_T(java.lang.annotation,"RetentionPolicy",Enum);
$_E(c$,"SOURCE",0,[]);
$_E(c$,"CLASS",1,[]);
$_E(c$,"RUNTIME",2,[]);
});
