$_L(["java.lang.LinkageError"],"java.lang.UnsatisfiedLinkError",null,function(){
c$=$_T(java.lang,"UnsatisfiedLinkError",LinkageError);
});
