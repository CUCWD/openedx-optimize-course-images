$_L(["java.lang.RuntimeException"],"java.util.EmptyStackException",null,function(){
c$=$_T(java.util,"EmptyStackException",RuntimeException);
});
