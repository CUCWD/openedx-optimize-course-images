$_L(["java.lang.RuntimeException"],"java.util.ConcurrentModificationException",null,function(){
c$=$_T(java.util,"ConcurrentModificationException",RuntimeException);
$_K(c$,
function(){
$_R(this,java.util.ConcurrentModificationException,[]);
});
});
