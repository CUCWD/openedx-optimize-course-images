$_L(["java.util.IllegalFormatException"],"java.util.IllegalFormatCodePointException",null,function(){
c$=$_C(function(){
this.c=0;
$_Z(this,arguments);
},java.util,"IllegalFormatCodePointException",java.util.IllegalFormatException,java.io.Serializable);
$_K(c$,
function(c){
$_R(this,java.util.IllegalFormatCodePointException,[]);
this.c=c;
},"~N");
$_M(c$,"getCodePoint",
function(){
return this.c;
});
$_V(c$,"getMessage",
function(){
return"Code point is "+this.c;
});
});
