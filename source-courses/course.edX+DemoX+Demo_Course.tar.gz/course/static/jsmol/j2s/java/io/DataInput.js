Clazz.declareInterface (java.io, "DataInput");
